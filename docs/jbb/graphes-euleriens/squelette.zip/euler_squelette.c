#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>

#include "stack.h"
#include "graph.h"


int *read_data(int *nb_vertex, int *nb_edges);

stack *euler_tour(graph g);

int main(void){

    return 0;
}
